# 🌍 Global Happiness Report Analysis

> A Python-based exploratory data analysis project examining country-level happiness and its relationship with GDP per capita, social support, healthy life expectancy, and other selected factors.

## 📌 Project Overview

This project analyzes Global Happiness Report data using Python to explore patterns in country-level life evaluation and selected factors associated with happiness.

The analysis includes:

- 🌍 Country-wise happiness analysis
- 🏆 Top 10 happiest countries
- 📉 Bottom 10 countries by happiness
- 💰 GDP per capita vs happiness
- 🤝 Social support vs happiness
- ❤️ Healthy life expectancy vs happiness
- 🔗 Correlation analysis
- 🧹 Data-quality checks
- 📊 Data visualizations
- 💡 Data-driven observations

## 🎯 Objectives

1. Explore the Global Happiness Report dataset.
2. Examine dataset structure, dimensions, columns, and data types.
3. Check missing values and duplicate records.
4. Identify the Top 10 happiest countries in the latest available year.
5. Identify the Bottom 10 countries by life evaluation.
6. Explore social support, healthy life expectancy, and GDP per capita in relation to happiness.
7. Examine correlations between selected happiness-related factors.
8. Create meaningful visualizations using Matplotlib and Seaborn.
9. Communicate observations responsibly.
10. Distinguish correlation from causation.

## 📂 Dataset

**Dataset:** Global Happiness Report

- **Rows:** 1,969
- **Columns:** 13
- **Year range:** 2011–2024
- **Primary measure:** `Life evaluation (3-year average)`

### Main Variables

`Year`, `Rank`, `Country name`, `Life evaluation (3-year average)`, `Lower whisker`, `Upper whisker`, `Log GDP per capita`, `Social support`, `Healthy life expectancy`, `Freedom to make life choices`, `Generosity`, `Perceptions of corruption`, `Dystopia + residual`

## 🛠️ Technologies

- Python
- Pandas
- NumPy
- Matplotlib
- Seaborn
- Jupyter Notebook

## 🔍 Analysis Performed

### 1. Data Exploration
Dataset dimensions, columns, data types, years, countries, and main variables are examined.

### 2. Data Quality
Missing values and duplicate records are checked before the main analysis.

### 3. Top 10 Happiest Countries
The latest available year is used to identify and visualize the Top 10 countries by life evaluation.

### 4. Bottom 10 Countries
The Bottom 10 countries by life evaluation are identified and visualized.

### 5. GDP per Capita vs Happiness
A scatter plot with a trend line examines the relationship between `Log GDP per capita` and `Life evaluation`.

### 6. Social Support vs Happiness
A scatter plot explores `Social support` against `Life evaluation`.

### 7. Healthy Life Expectancy vs Happiness
A scatter plot explores `Healthy life expectancy` against `Life evaluation`.

### 8. Correlation Analysis
A correlation matrix and heatmap summarize relationships between selected numerical variables.

> **Important:** Correlation represents statistical association. It does not prove causation.

## 📊 Visualizations

1. 🏆 Top 10 Happiest Countries
2. 📉 Bottom 10 Countries by Happiness
3. 💰 GDP per Capita vs Happiness
4. 🤝 Social Support vs Happiness
5. ❤️ Healthy Life Expectancy vs Happiness
6. 🔗 Correlation Heatmap

## 📁 Project Structure

```text
Global-Happiness-Report-Analysis/
│
├── README.md
│
├── data/
│   └── Global_Happiness_Report.csv
│
├── notebook/
│   └── Global_Happiness_Report_Analysis.ipynb
│
└── output/
    ├── top_10_happiest_countries.csv
    ├── bottom_10_countries.csv
    └── happiness_correlation_matrix.csv
```

## ▶️ How to Run

```bash
git clone https://github.com/rajgorshyam18-lab/Global-Happiness-Report-Analysis.git
cd Global-Happiness-Report-Analysis
pip install pandas numpy matplotlib seaborn jupyter
jupyter notebook
```

Open:

```text
notebook/Global_Happiness_Report_Analysis.ipynb
```

The notebook loads the dataset from:

```text
../data/Global_Happiness_Report.csv
```

Run the cells from top to bottom.

## ⚠️ Assumptions & Limitations

### Assumptions
- The supplied Global Happiness Report dataset is used as the source.
- `Life evaluation (3-year average)` is the primary happiness measure.
- The latest available year is used for the main ranking analysis.
- Missing-value and duplicate checks are performed before analysis.
- Correlation is treated as exploratory statistical association.

### Limitations
- Correlation does not imply causation.
- Country-level observations should not automatically be interpreted as individual-level behavior.
- Life evaluation is based on reported assessments and does not represent every aspect of wellbeing.
- The primary measure is a 3-year average.
- The analysis focuses on selected available factors.

## 📚 What I Learned

This project helped me practice Python, Pandas, data cleaning, exploratory data analysis, visualization, correlation analysis, and responsible interpretation of statistical relationships.

## 🎓 Academic Purpose

This project was created for educational and academic purposes as part of my Python and Data Analytics learning journey.

## 👨‍💻 Author

**Shyam Gor**

Aspiring Data Analyst | Python | Pandas | Data Visualization | Exploratory Data Analysis

## 🙏 Acknowledgement

I would like to acknowledge the Global Happiness Report dataset used for this educational analysis.

## ⭐ Thank You

Thank you for taking the time to review my project.

Working on this project gave me an opportunity to apply Python and Data Analytics concepts to a practical real-world dataset.

I look forward to continuing my learning journey, building more projects, and improving my ability to turn data into meaningful insights.
